public interface UpdateAccountInterface {
    void updatePassword();
    void updateAge();
}
